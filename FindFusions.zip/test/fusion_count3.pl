#this is a scirpt which parses the STAR-FUSION result sets and allows identification of transposon insertion sites and fusions.
# Version 5.1 UPDATED FEB 18,2018
#b_rna.txt contain the root names for the analyses sections...
open SOURCE,"< data.txt";
while (defined($line = <SOURCE>)) {
chomp $line;
@val= split(/\t/, $line);
open OUT,"> mouse_list.txt";
print "$val[3]\n";
# open a txt document process line by line
`grep chrSB out/out_$val[3]/Chimeric.out.junction > out/out_$val[3]/test`;

 open SOURCE2,"< out/out_$val[3]/test";
  open OUT,"> out/out_$val[3]/double";
  while (defined($lin = <SOURCE2>)) {
    chomp $lin;
    @va= split(/\t/, $lin);
      if (($va[0] eq 'chrSB') and ($va[3] ne 'chrSB') and ($va[3] ne 'chrSB11')) {
      print OUT "$lin\n";
      }
      if (($va[3] eq 'chrSB') and ($va[0] ne 'chrSB') and ($va[0] ne 'chrSB11')) {
      print OUT "$va[3]\t$va[4]\t";
       if($va[5] eq '+') {
           print OUT "-\t$va[0]\t$va[1]\t";
            }
        if($va[5] eq '-') {
           print OUT "+\t$va[0]\t$va[1]\t";
            }
       if($va[2] eq '+') {
           print OUT "-\t";
            }
        if($va[2] eq '-') {
           print OUT "+\t";
            }
        
        if($va[6] eq '1') {
           print OUT "2\t" 
          }
       if($va[6] eq '2') {
           print OUT "1\t" 
          }

       if($va[6] eq '-1') {
           print OUT "-1\t" 
          }
       if($va[6] eq '0') {
           print OUT "0\t"
          }

       print OUT "$va[8]\t$va[7]\t$va[9]\t$va[10]\t$va[11]\t$va[12]\t$va[13]\t\n";
      }

}


`cat out/out_$val[3]/double |awk '\$1!='chrM' && \$4!='chrM' && \$7>0 && \$8+\$9<=5 {print \$1,\$2,\$3,\$4,\$5,\$6,\$7,\$8,\$9}' |sort | uniq -c | sort -k1,1rn > out/out_$val[3]/double2`;

`tr -s ' '  < out/out_$val[3]/double2 > out/out_$val[3]/double3`;
`tr ' ' \\\t < out/out_$val[3]/double3 > out/out_$val[3]/double4`;
`sort -k5,5 -k6,6n out/out_$val[3]/double4 > out/out_$val[3]/double5`; 
open SOURCE2,"< out/out_$val[3]/double5";
  open OUT,"> out/out_$val[3]/test.bed";
  while (defined($lin = <SOURCE2>)) {
    chomp $lin;
    @va= split(/\t/, $lin);
    $plus =$va[6]+1;
    print OUT "$va[5]\t$va[6]\t$plus\t$va[7]\t$va[1]\t$va[2]\t$va[3]\t$va[4]\t$val[3]\n";
}
`bedtools closest -d -a  out/out_$val[3]/test.bed -b test_sorted.gtf -wo > out/out_$val[3]/SB_FUSIONS_$val[3]`;
`grep chrSB out/out_$val[3]/Chimeric.out.sam > out/out_$val[3]/test2`;

#here is where the addional script steps go Oct-4-2017
open SOURCE3, "< out/out_$val[3]/test2";
open OUT, "> out/out_$val[3]/loc.txt";
$count=0;
while (defined($line3 = <SOURCE3>)) {
chomp $line;
@field= split(/\t|\s+/, $line3);
#Mod Feb 2018  here we are reporting both sides of the bridge with chromosomal followed by SB,
#May want to add the logic for binning here. as it would be very clear. read through, spice acceptor,splice donor,splice acceptor read through.
if (($field[2] eq "chrSB") and ($field[3] < 300)) {
print OUT "$field[6]\t$field[7]\t$field[2]\t$field[3]\t1\n";
}
if (($field[2] eq "chrSB") and ($field[3] > 299) and ($field[3] < 750)) {
print OUT "$field[6]\t$field[7]\t$field[2]\t$field[3]\t457\n";
}
if (($field[2] eq "chrSB") and ($field[3] > 749) and ($field[3] < 1200)) {
print OUT "$field[6]\t$field[7]\t$field[2]\t$field[3]\t1080\n";
}
if (($field[2] eq "chrSB") and ($field[3] > 1199) and ($field[3]< 1800)) {
print OUT "$field[6]\t$field[7]\t$field[2]\t$field[3]\t1578\n";
}
if (($field[2] eq "chrSB") and ($field[3] > 1799)) {
print OUT "$field[6]\t$field[7]\t$field[2]\t$field[3]\t2200\n";
}

if (($field[6] eq "chrSB")and ($field[7] < 300)) {
print OUT "$field[2]\t$field[3]\t$field[6]\t$field[7]\t1\n";
}
if (($field[6] eq "chrSB")and ($field[7] > 299)and($field[7] < 750)) {
print OUT "$field[2]\t$field[3]\t$field[6]\t$field[7]\t457\n";
}

if (($field[6] eq "chrSB")and ($field[7] > 749)and ($field[3] < 1200)) {
print OUT "$field[2]\t$field[3]\t$field[6]\t$field[7]\t1080\n";
}
if (($field[6] eq "chrSB")and ($field[7] > 1199)and ($field[7] < 1800)) {
print OUT "$field[2]\t$field[3]\t$field[6]\t$field[7]\t1578\n";
}
if (($field[6] eq "chrSB")and ($field[7] > 1799)) {
print OUT "$field[2]\t$field[3]\t$field[6]\t$field[7]\t2200\n";
}





}
close OUT;
`sort -k1,1 -k2n,2 out/out_$val[3]/loc.txt > out/out_$val[3]/loc2.txt`;
open SOURCE3, "< out/out_$val[3]/loc2.txt";
open OUT, "> out/out_$val[3]/nr.txt";
open OUT2, "> out/out_$val[3]/nr2.txt";
$count=0;
while (defined($line3 = <SOURCE3>)) {
chomp $line3;
@field= split(/\t|\s+/, $line3);
$count++;
print "$count\n";
if ($field[0] ne "=") {
if ($field[0] ne "*") {
if ($field[0] ne "chrSB") {
if ($field[0] ne "chrM") {
if ($field[0] ne "chrSB11"){
$round1=1000*int(0.5+$field[1]/1000);
$round2=50000*int(0.5+$field[1]/50000);
print OUT "$field[0]\t$round1\t$field[2]\t$field[4]\n";
print OUT2 "$field[0]\t$round2\t$field[2]\t$field[4]\n";
}
}
}
}
}
}
close OUT;
close OUT2;
system "uniq -c out/out_$val[3]/nr.txt > out/out_$val[3]/cis1.txt";
system "uniq -c out/out_$val[3]/nr2.txt > out/out_$val[3]/cis2.txt";
open SOURCE3, "< out/out_$val[3]/cis1.txt";
open OUT, "> out/out_$val[3]/$val[6]_bridge.bedGraph"; 
print OUT "track type=bedGraph name=\"$val[6] Bridge Fusions\" description=\"BedGraph format\" visibility=full color=200,100,0 altColor=0,100,200 priority=20\n";
while (defined($line3 = <SOURCE3>)) {
chomp $line;
@field= split(/\t|\s+/, $line3);
$start= $field[3]-500;
$stop= $field[3]+500;
$val= `samtools view -c bam_files/$val[2]_sorted.bam $field[2]:$start-$stop`;
chomp $val;
$cpm=($field[1]/$val[5])*1000000;
print OUT "$field[2]\t$start\t$stop\t$field[1]\t$field[4]\t$field[5]\tbridge\t$val\t$cpm\t$val[6]\n";
}
open SOURCE3, "< out/out_$val[3]/cis2.txt";
open OUT, "> out/out_$val[3]/$val[6]_bridge_50000.bedGraph";
print OUT "track type=bedGraph name=\"$val[3] Bridge Fusions\" description=\"BedGraph format\" visibility=full color=200,100,0 altColor=0,100,200 priority=20\n";
while (defined($line3 = <SOURCE3>)) {
chomp $line;
@field= split(/\t|\s+/, $line3);
$start= $field[3]-25000;
$stop= $field[3]+25000;
print OUT "$field[2]\t$start\t$stop\t$field[1]\t$field[4]\t$field[5]\tbridge\n";
}


open SOURCE3, "< out/out_$val[3]/SB_FUSIONS_$val[3]";
open OUT, "> out/out_$val[3]/$val[6]_junction.bedGraph";    
print OUT "track type=bedGraph name=\"$val[6] Junction Fusions\" description=\"BedGraph format\" visibility=full color=200,100,0 altColor=0,100,200 priority=20\n";
while (defined($line3 = <SOURCE3>)) {
chomp $line;
@field= split(/\t|\s+/, $line3);
$st1=$field[1]-150;
$st2=$field[1]+150;
$val= `samtools view -c bam_files/$val[2]_sorted.bam $field[0]:$st1-$st2`;
chomp $val;
$cpm=$field[4]/$val[5]*1000000;
print OUT "$field[0]\t$field[1]\t$field[2]\t$field[4]\t$field[5]\t$field[6]\t$field[7]\t$val\t$cpm\t$val[6]\n";
}

`bedtools intersect -loj -a out/out_$val[3]/SB_FUSIONS_$val[3] -b out/out_$val[3]/$val[6]_bridge_50000.bedGraph > out/out_$val[3]/SB_FUSIONS_$val[6]_fusion_support.txt`;  
print "bedtools intersect -loj -a out/out_$val[3]/SB_FUSIONS_$val[3] -b out/out_$val[3]/$val[3]_bridge_50000.bedGraph > out/out_$val[3]/SB_FUSIONS_$val[7]_fusion_support.txt";

open SOURCE3, "< out/out_$val[3]/SB_FUSIONS_$val[6]_fusion_support.txt";
open OUT, "> out/results/$val[6]_fusions.txt";
while (defined($line3 = <SOURCE3>)) {
chomp $line3;
@field= split(/\t|\s+/, $line3);
if($field[18] > $field[4]) {
print OUT "$val[7]\t$line3\n";
}
}
#here is the start of fusion_count2.pl
#annotate the gene names
`bedtools closest -d -a  out/out_$val[3]/$val[6]_bridge.bedGraph -b test_sorted.gtf -wo > out/out_$val[3]/SB_Bridges_$val[6]`;
`bedtools closest -d -a  out/out_$val[3]/$val[6]_junction.bedGraph -b test_sorted.gtf -wo > out/out_$val[3]/SB_Junctions_$val[6]`;

} #closes the loop  
